<?php
//Step 1: Rename the index file so that the PHP code will be executed.

//Step 2: Add a code block to the top of index and create a variable named $title and set it's value equal to "Top 5 Learning Tips"

//Step 3: Replace the TWO instances of the text "TITLE" with your variable in such a way that in a web browser the value of the variable will be displayed on the page.

//Step 4: Replace the text "INCLUDE QUOTES" by *including* the HTML file "learning_quotes.html" from the "inc" folder.

//Step 5: Replace the text "INCLUDE TIPS" by *including* the HTML file "learning_tips.html" from the "inc" folder.

/*Step 6: Use the built in "date" function to replace the text "DATE" with today's date. 
Look at the documentation for formatting: http://php.net/manual/en/function.date.php
You may choose any format you wish. I will use the full name of the month, followed by a space and the two digit day, followed by a comma space then the 4 digit year. 
Example: December 09, 1906*/